import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class FoodOrderDAO {
	
	protected static EntityManagerFactory emf =  Persistence.createEntityManagerFactory("ellaPU");

	public FoodOrderDAO() {
	
	}
	
	public void persistOrder(FoodOrder foodorder) {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		em.persist(foodorder);
		em.getTransaction().commit();
		em.close();
	}
	
	public List<FoodOrder> getAllFoodOrders(){
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		List<FoodOrder> foodOrderList = new ArrayList<FoodOrder>();
		foodOrderList = em.createQuery("from FoodOrder").getResultList();
		em.getTransaction().commit();	
		em.close();
		return foodOrderList;

	}

	public FoodOrder getOrderByID(int orderId) {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		List<FoodOrder> foodOrderList = new ArrayList<FoodOrder>();
		foodOrderList = em.createQuery("from FoodOrder").getResultList();
		for(FoodOrder foodorder: foodOrderList) {
			if(foodorder.getId()==orderId) {
				em.getTransaction().commit();	
				em.close();
				return foodorder;			
			}
		}
		return null;
	}
	
	
	

}
