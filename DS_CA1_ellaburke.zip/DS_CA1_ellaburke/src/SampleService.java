

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;


@Path("service")
public class SampleService {


	// GET REQUESTS
	// Get all Users(Customers) in DB in HTML
	@GET
	@Path("/getUsers")
	@Produces(MediaType.TEXT_HTML)
	public String getUsers() {
		UserDAO userDAO = new UserDAO();
		String userList = null;
		for(User user : userDAO.getAllUsers()) {
			userList = userList + ", " + user.getFirstName();
		}
		return userList;
	}
	
	//1. Get all Users(Customers) in DB in JSON
		@GET
		@Path("/getUsersJSON")
		@Produces("application/json")
			public List<User> getUsersJSON(){
				UserDAO userDAO = new UserDAO();
				return userDAO.getAllUsers();
			}
		
		
		
	//1A. Get all Users(Customers) in DB in XML
		@GET
		@Path("/getUsersXML")
		@Produces("application/xml")
		public List<User> getUsersXML(){
			UserDAO userDAO = new UserDAO();
			return userDAO.getAllUsers();
		}
		
		@GET
		@Path("/getUserIdJSON/{id}")
		@Produces("application/json")
		public User getUserByIdJSON(@PathParam("id")String id) {
			UserDAO userDAO = new UserDAO();
			int userId = Integer.parseInt(id);
			return userDAO.getUserByID(userId);

		}
		
	//1B. Get user by ID in XML
		@GET
		@Path("/getUserIdXML/{id}")
		@Produces("application/xml")
		public User getUserByIdXML(@PathParam("id")String id) {
			UserDAO userDAO = new UserDAO();
			int userId = Integer.parseInt(id);
			return userDAO.getUserByID(userId);
		}
		
	//2. Get User(customer) by first name in JSON
		@GET
		@Path("/getUserFirstNameJSON/{userName}")
		@Produces("application/json")
		public User getUserFirstNameJSON(@PathParam("userName")String userFirstName) {
			UserDAO userDAO = new UserDAO();
			return userDAO.getUserFirstName(userFirstName);
		}
		
	//2A. Get User(customer) by first name in XML
		@GET
		@Path("/getUserFirstNameXML/{userName}")
		@Produces("application/xml")
		public User getUserFirstNameXML(@PathParam("userName")String userFirstName) {
			UserDAO userDAO = new UserDAO();
			return userDAO.getUserFirstName(userFirstName);
		}
		
		
	//3. Get user(customer) by email in JSON
		@GET
		@Path("/getUserEmailJSON/{userEmail}")
		@Produces("application/json")
		public List<String> getUserEmailJSON(@PathParam("userEmail")String userEmail) {
			UserDAO userDAO = new UserDAO();
			return userDAO.getUserEmails(userEmail);
		}
		
	//3A. Get user(customer) by email in XML
		@GET
		@Path("/getUserEmailXML/{userEmail}")
		@Produces("application/xml")
		public List<String> getUserEmailXML(@PathParam("userEmail")String userEmail) {
			UserDAO userDAO = new UserDAO();
			return userDAO.getUserEmails(userEmail);
				}
		
	
	//4. Get all Food Items in JSON
		@GET
		@Path("/getFoodItemsJSON")
		@Produces("application/json")
		public List <FoodItem> getFoodItemsJSON(){
			FoodItemDAO fooditemDAO = new FoodItemDAO();
			return fooditemDAO.getAllFoodItems();
		}
		
	//4A. Get all Food Items in XML
		@GET
		@Path("/getFoodItemsXML")
		@Produces("application/xml")
		public List <FoodItem> getFoodItemsXML(){
			FoodItemDAO fooditemDAO = new FoodItemDAO();
			return fooditemDAO.getAllFoodItems();
				}
		
	//4B. Get food item by ID in XML
		@GET
		@Path("/getFoodIdXML/{id}")
		@Produces("application/xml")
		public FoodItem getFoodByIdXML(@PathParam("id")String id) {
			FoodItemDAO fooditemDAO = new FoodItemDAO();
			int foodId = Integer.parseInt(id);
			return fooditemDAO.getFoodByID(foodId);
		}
		
		
	//4C. Get food item by ID in JSON
		@GET
		@Path("/getFoodIdJSON/{id}")
		@Produces("application/json")
		public FoodItem getFoodByIdJSON(@PathParam("id")String id) {
			FoodItemDAO fooditemDAO = new FoodItemDAO();
			int foodId = Integer.parseInt(id);
			return fooditemDAO.getFoodByID(foodId);
		}
		
		
	//5. Get Food Item by name in JSON
		@GET
		@Path("/getFoodItemNameJSON/{foodItemName}")
		@Produces("application/json")
		public FoodItem getFoodItemByNameJSON(@PathParam("foodItemName")String foodName) {
			FoodItemDAO foodItemDAO = new FoodItemDAO();
			return foodItemDAO.getFoodItemByName(foodName);
		}
		
	//5A. Get Food Item by name in XML
		@GET
		@Path("/getFoodItemNameXML/{foodItemName}")
		@Produces("application/xml")
		public FoodItem getFoodItemByNameXML(@PathParam("foodItemName")String foodName) {
			FoodItemDAO foodItemDAO = new FoodItemDAO();
			return foodItemDAO.getFoodItemByName(foodName);
		}
		
	//6. Get all Food Orders in JSON
		@GET
		@Path("/getOrdersJSON")
		@Produces("application/json")
		public List<FoodOrder> getOrdersJSON(){
			FoodOrderDAO foodOrderDAO = new FoodOrderDAO();
			return foodOrderDAO.getAllFoodOrders();
		}
		
	//6A. Get all Food Orders in XML
		@GET
		@Path("/getOrdersXML")
		@Produces("application/xml")
		public List<FoodOrder> getOrdersXML(){
			FoodOrderDAO foodOrderDAO = new FoodOrderDAO();
			return foodOrderDAO.getAllFoodOrders();
		}
		
	//6B. Get food order by ID in JSON
		@GET
		@Path("/getFoodOrderIdJSON/{id}")
		@Produces("application/json")
		public FoodOrder getFoodOrderByIdJSON(@PathParam("id")String id) {
			FoodOrderDAO foodorderDAO = new FoodOrderDAO();
			int orderId = Integer.parseInt(id);
			return foodorderDAO.getOrderByID(orderId);
		}
		
		
	//POST 
	//1. Add new user to DB in XML
		@POST
		@Path("/createNewUserXML")
		@Consumes("application/xml")
		public String createNewUserXML(User user) {
			UserDAO userDAO = new UserDAO();
			userDAO.persistUser(user);
			return user.getFirstName()+ "has been created";
		}
		
	
	//1A. Add new user to DB in JSON
		@POST
		@Path("/createNewUserJSON")
			@Consumes("application/json")
		public String createNewUserJSON(User user) {
			UserDAO userDAO = new UserDAO();
			userDAO.persistUser(user);
			return user.getFirstName()+ "has been created";
			}
		
	//2. Add new food item to DB in JSON	
		@POST
		@Path("/createNewFoodItemJSON")
			@Consumes("application/json")
		public String createNewFoodItemJSON(FoodItem food) {
			FoodItemDAO fooditemDAO = new FoodItemDAO();
			fooditemDAO.persistFoodItem(food);
			return food.getFoodName()+ " has been created";
			}
		
	//2A. Add new food item to DB in XML
		@POST
		@Path("/createNewFoodItemXML")
			@Consumes("application/xml")
		public String createNewFoodXML(FoodItem food) {
			FoodItemDAO fooditemDAO = new FoodItemDAO();
			fooditemDAO.persistFoodItem(food);
			return food.getFoodName()+ " has been created";
			}
	
	//3. Create new order in JSON
		@POST
		@Path("/createNewFoodOrderJSON")
			@Consumes("application/json")
		public String createNewFoodOrderJSON(FoodOrder foodorder) {
			FoodOrderDAO foodorderDAO = new FoodOrderDAO();
			foodorderDAO.persistOrder(foodorder);
			return foodorder.getId()+ " has been created";
			}
		
	//3A. Create new order in XML
		@POST
		@Path("/createEmptyFoodOrderXML")
			@Consumes("application/xml")
		public String createNewFoodOrderXML(FoodOrder foodorder) {
			FoodOrderDAO foodorderDAO = new FoodOrderDAO();
			foodorderDAO.persistOrder(foodorder);
			return foodorder.getId()+ " has been created";
			}
			
			
			
	//DELETE
	//1. Delete User by First Name
		//@GET
		//@Path("/remove/{firstName}")
		//public String deleteByName(@PathParam("name") String firstName) {
	//		UserDAO userDAO = new UserDAO();
	//		userDAO.removeUser(userDAO.getUserFirstName(firstName));
	//		return "Removed: " + firstName;
	//	}
					
		
	/*
	// Get all FoodItems(Food Products) in DB
	@GET
	@Path("/getFoodItems")
	@Produces(MediaType.TEXT_HTML)
	public String getFoodItems() {
		FoodItemDAO foodItemDAO = new FoodItemDAO();
		String foodItemList = null;
		for(FoodItem foodItem : foodItemDAO.getAllFoodItems()) {
			foodItemList = foodItemList + ", " + foodItem.getFoodName();
		}
		return foodItemList;
	}
	
	// Get all Food Orders in DB
		@GET
		@Path("/getFoodOrders")
		@Produces(MediaType.TEXT_HTML)
		public String getFoodOrders() {
			FoodOrderDAO foodOrderDAO = new FoodOrderDAO();
			String foodOrderList = null;
			for(FoodOrder foodOrder : foodOrderDAO.getAllFoodOrders()) {
				foodOrderList = foodOrderList + ", " + foodOrder.getOrder();
			}
			return foodOrderList;
		}*/

	@GET

	@Path("/tester")

	@Produces("text/plain")

	public String test() {

		return "Please please please work";

	}
	
	

}
