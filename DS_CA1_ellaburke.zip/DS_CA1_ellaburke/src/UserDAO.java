import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class UserDAO {
	
	protected static EntityManagerFactory emf =  Persistence.createEntityManagerFactory("ellaPU");

	public UserDAO() {
	
	}
	
	public void persistUser(User user) {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		em.persist(user);
		em.getTransaction().commit();
		em.close();
	}

	public List<User> getAllUsers(){
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		List<User> userList = new ArrayList<User>();
		userList = em.createQuery("from User").getResultList();
		em.getTransaction().commit();	
		em.close();
		return userList;

	}
	
	public User getUserFirstName(String firstName) {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		List<User> userList = new ArrayList<User>();
		userList = em.createQuery("from User").getResultList();
		for(User user: userList) {
			if(user.getFirstName().equalsIgnoreCase(firstName)) {
				em.getTransaction().commit();	
				em.close();
				return user;
				
			}
		}
		return null;
		
	}
	
	public List <String> getUserEmails(String email){
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		List<User> userList = new ArrayList<User>();
		List<String> userEmailList = new ArrayList<String>();
		userEmailList = em.createQuery("from User").getResultList();
		for(User user : userList) {
			userEmailList.add(user.getEmail());
		}
		em.getTransaction().commit();	
		em.close();
		return userEmailList;
		
	}

	public User getUserByID(int id) {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		List<User> userList = new ArrayList<User>();
		userList = em.createQuery("from User").getResultList();
		for(User user: userList) {
			if(user.getId()==id) {
				em.getTransaction().commit();	
				em.close();
				return user;			
			}
		}
		return null;		
	}

}
