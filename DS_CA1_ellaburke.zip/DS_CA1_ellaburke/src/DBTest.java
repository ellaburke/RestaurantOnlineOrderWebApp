import java.util.ArrayList;
import java.util.List;

public class DBTest {
	
	public static void main(String[] args) {
		UserDAO userDAO = new UserDAO();
		FoodOrderDAO orderDAO = new FoodOrderDAO();
		FoodItemDAO foodItemDAO = new FoodItemDAO();
		
		//Creating Customer
		User user = new User("Ella","Burke","burke@gmail.com","0833247129","Dublin");
		//Creating food items 
		FoodItem item1 = new FoodItem("drink",2,"Coke");
		FoodItem item2 = new FoodItem("side",4,"Garlic Bread");
		FoodItem item3 = new FoodItem("Main",5,"Pizza");
		
		List<FoodItem> cart = new ArrayList<FoodItem>();//creating a list of items (shopping cart)
		
		
		cart.add(item1);// add items to cart
		cart.add(item3);
		
		FoodOrder foodorder = new FoodOrder(user, cart); //creating a new order
	
		
		foodItemDAO.persistFoodItem(item1);
		foodItemDAO.persistFoodItem(item2);
		foodItemDAO.persistFoodItem(item3);
		userDAO.persistUser(user);
		orderDAO.persistOrder(foodorder);
	
		
	}

}
