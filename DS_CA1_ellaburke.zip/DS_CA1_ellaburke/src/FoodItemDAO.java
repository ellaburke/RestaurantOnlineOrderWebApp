import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class FoodItemDAO {
	
	protected static EntityManagerFactory emf =  Persistence.createEntityManagerFactory("ellaPU");

	public FoodItemDAO() {
	
	}
	
	public void persistFoodItem(FoodItem foodItem) {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		em.persist(foodItem);
		em.getTransaction().commit();
		em.close();
	}
	
	public List<FoodItem> getAllFoodItems(){
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		List<FoodItem> foodItemList = new ArrayList<FoodItem>();
		foodItemList = em.createQuery("from FoodItem").getResultList();
		em.getTransaction().commit();	
		em.close();
		return foodItemList;

	}
	
	public FoodItem getFoodItemByName(String foodName) {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		List<FoodItem> foodItemList = new ArrayList<FoodItem>();
		foodItemList = em.createQuery("from FoodItem").getResultList();
		for(FoodItem fi: foodItemList) {
			if(fi.getFoodName().equalsIgnoreCase(foodName)) {
				em.getTransaction().commit();	
				em.close();
				return fi;
				
			}
		}
		return null;
		
	}
	
	public List <String> getFoodItems(String foodItems){
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		List<FoodItem> foodItemList = new ArrayList<FoodItem>();
		List<String> foodNameList = new ArrayList<String>();
		foodNameList = em.createQuery("from FoodItem").getResultList();
		for(FoodItem fi : foodItemList) {
			foodNameList.add(fi.getFoodName());
		}
		em.getTransaction().commit();	
		em.close();
		return foodNameList;
		
	}

	public FoodItem getFoodByID(int foodId) {
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		List<FoodItem> foodList = new ArrayList<FoodItem>();
		foodList = em.createQuery("from FoodItem").getResultList();
		for(FoodItem food: foodList) {
			if(food.getId()==foodId) {
				em.getTransaction().commit();	
				em.close();
				return food;			
			}
		}
		return null;		
	}

}
