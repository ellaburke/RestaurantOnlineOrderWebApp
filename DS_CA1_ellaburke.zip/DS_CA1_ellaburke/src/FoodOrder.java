import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.xml.bind.annotation.XmlRootElement;
@Entity
@XmlRootElement(name="foodorder")
public class FoodOrder {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	
	@OneToOne
	private User user = new User();
	
	@ManyToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
	private List<FoodItem> order = new ArrayList<FoodItem>();

	public FoodOrder() {
		
		// TODO Auto-generated constructor stub
	}

	public FoodOrder(User user, List<FoodItem> order) {
		super();
		this.user = user;
		this.order = order;
	}

	public List<FoodItem> getOrder() {
		return order;
	}

	public void setOrder(List<FoodItem> order) {
		this.order = order;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
	
	
	
	
	
	

}
